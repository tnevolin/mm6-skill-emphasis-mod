extern "C"
{
	#include "lua.h"
}
void RSMemRegister(lua_State *L);