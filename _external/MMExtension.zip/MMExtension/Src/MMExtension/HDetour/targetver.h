#pragma once

#ifndef _WIN32_WINNT
#	define _WIN32_WINNT 0x0501
#endif

