#pragma once

void WriteHooks(int queue = 0);
// queue values: