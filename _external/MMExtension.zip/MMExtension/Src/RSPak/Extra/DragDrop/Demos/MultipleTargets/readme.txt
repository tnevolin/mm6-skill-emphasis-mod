MultiTarget

This application demonstrates how to use a single drop target component with
multiple controls.

Also demonstrates the FindTarget target component method and the OnEnter and
OnLeave target component events.

Previous version of the Drag and Drop Component Suite only allowed one to
register a single control per target component. With version 4 any number of
controls can be registered against the same target component.

