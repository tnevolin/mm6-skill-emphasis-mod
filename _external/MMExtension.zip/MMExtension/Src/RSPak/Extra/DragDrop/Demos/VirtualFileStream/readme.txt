VirtualFileStream

This application demonstrates how to transfer file content or virtual files
(files which doesn't exist physically on disk) via a stream .

The application uses the TDropEmptySource and TDropEmptyTarget components and
extends them with TDataFormatAdapter components.

