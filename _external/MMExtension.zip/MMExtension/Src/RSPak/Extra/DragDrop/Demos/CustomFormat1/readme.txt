CustomFormat1

This application demonstrates how to define and use custom data formats.

The custom format used in this demo contains the time-of-day and a color value.
The TGenericDataFormat class is used to add support for this format to the
TDropTextSource and TDropTextTarget components.

To see the custom data format in action, drag from the source window and
drop on the target window. You can also do this between multiple instances of
any of the CustomFormat demo applications.

