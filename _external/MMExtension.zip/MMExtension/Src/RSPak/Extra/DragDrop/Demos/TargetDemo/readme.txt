SimpleTargetDemo

This application demonstrates how to receive file names dragged from other
applications (e.g. the Explorer) using the TDropFileTarget component.

Only copy and link operations are enabled in this demo to avoid "accidents". The
TDropFileTarget.DragTypes property control which drag/drop operations the drop
source allows.

