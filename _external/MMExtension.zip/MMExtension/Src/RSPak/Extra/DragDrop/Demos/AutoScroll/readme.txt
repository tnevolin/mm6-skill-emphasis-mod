AutoScroll

This application is undocumented.

