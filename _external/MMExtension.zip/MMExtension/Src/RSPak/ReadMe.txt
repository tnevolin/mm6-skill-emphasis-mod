RSPak - modules and components package

Hi all,
This package is a collection of things I've made for my own use over the years.
No Help included, but programs on my site can serve as examples of use.
Many components were changed slightly, some were changed significantly.

The package was tested with Delphi 2006. If you change things in it to work 
right under another Delphi version, send it to me. All modules, excepting 
RSTimer, are made to work under Windows only. No Unicode and 64 bit 
architectures support.

Files in Extra folder aren't included in the package, but most are used by my
programs.


Rozhenko Sergey aka GrayFace aka sergroj
http://sites.google.com/site/sergroj/