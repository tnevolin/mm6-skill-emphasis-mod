MMExtension
===

About
---

Coming to GitHub soon.

Setup
---

- Install latest versions of my patches. GrayFace patch version 2.1+ is required.

- In mm6.ini/mm7.ini/mm8.ini add these lines:

```ini
[ExeMods]
MMExtension=(path to the repository)\ExeMods\MMExtension.dll
```

- Make sure your game folder doesn't contain copies of MMExtension scripts and ExeMods\MMExtension.dll.

Now you can run the game.
