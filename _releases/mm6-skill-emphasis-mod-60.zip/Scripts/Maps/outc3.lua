-- configure shrine event
configureShrineEvent(261, 5, "BaseSpeed", 8, 9, 10, 11)

