-- configure shrine event
configureShrineEvent(261, 6, "BaseLuck", 23, 24, 25, 26)

