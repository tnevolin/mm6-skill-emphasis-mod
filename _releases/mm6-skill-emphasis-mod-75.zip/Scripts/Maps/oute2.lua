-- configure shrine event
configureShrineEvent(261, 1, "BaseIntellect", 15, 16, 17, 18)

