-- configure shrine event
configureShrineEvent(261, 2, "BasePersonality", 13, 14, 15, 16)

