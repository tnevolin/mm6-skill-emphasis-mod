# Might & Magic 6: skill emphasis mod installation

* Unpack archive into separate directory.
* Copy Scripts and DataFiles folders into game directory.

