-- configure shrine event
configureShrineEvent(261, 3, "BaseEndurance", 12, 13, 14, 15)

