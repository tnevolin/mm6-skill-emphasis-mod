-- configure shrine event
configureShrineEvent(262, 7, "FireResistance", 21, 22, 23, 24)
configureShrineEvent(261, 9, "ColdResistance", 14, 15, 16, 17)

