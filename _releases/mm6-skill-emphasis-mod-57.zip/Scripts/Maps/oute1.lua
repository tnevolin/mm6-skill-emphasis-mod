-- configure shrine event
configureShrineEvent(261, 10, "PoisonResistance", 7, 8, 9, 10)

