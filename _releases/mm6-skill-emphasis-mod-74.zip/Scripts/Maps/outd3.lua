-- configure shrine event
configureShrineEvent(261, 8, "ElecResistance", 18, 19, 20, 21)

