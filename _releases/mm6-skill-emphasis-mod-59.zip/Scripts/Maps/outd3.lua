-- configure shrine event
configureShrineEvent(261, 8, "BaseMight", 18, 19, 20, 21)

